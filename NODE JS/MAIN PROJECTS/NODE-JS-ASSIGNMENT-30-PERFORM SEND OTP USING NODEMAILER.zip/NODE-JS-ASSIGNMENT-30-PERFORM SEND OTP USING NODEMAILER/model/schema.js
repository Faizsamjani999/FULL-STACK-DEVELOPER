const mongoose = require('mongoose');

const schema = mongoose.Schema({
    fname : {
        type : String,
        require : true
    },
    lname : {
        type : String,
        require : true
    },
    number : {
        type : String,
        require : true
    },
    username : {
        type : String,
        require : true
    },
    password : {
        type : String,
        require : true
    }
})

const table = mongoose.model("table",schema);

module.exports = table;