const table = require("../model/schema");


const signup = (req,res)=>{
    res.render("signup")
}
const signin = (req,res)=>{
    res.render("signin");
}
const signupPost = (req,res)=>{
    table.create(req.body);
    console.log(req.body);
    res.redirect("/signin");
}
const signinPost = (req,res)=>{
    res.render("index");
}
const forgotPassword = (req,res)=>{
    res.render("forgot_password");
}



module.exports = {
    signup,
    signin,
    signupPost,
    signinPost,
    forgotPassword
    
}