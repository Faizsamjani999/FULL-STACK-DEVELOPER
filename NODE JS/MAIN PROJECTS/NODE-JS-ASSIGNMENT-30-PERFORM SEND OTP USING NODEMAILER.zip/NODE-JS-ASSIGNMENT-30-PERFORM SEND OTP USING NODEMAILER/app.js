const express = require('express');
const port = 9999;
const app = express();
const path = require('path');
const database = require('./config/database');
const table = require('./model/schema');

const otp = Math.floor(Math.random()*10000);

app.use(express.urlencoded());

const session = require('express-session');
app.use(session({secret : "private-key"}));
const passport = require('passport');
app.use(passport.initialize());
app.use(passport.session());
const localauth = require('./middleware/localauth');
localauth(passport);
const nodemailer = require('nodemailer');


app.set("view engine","ejs");
app.use(express.static(path.join(__dirname,"public")));

app.use(require('./routes/route'));

const sendMail = async(req,res)=>{

    const forgetEmail = req.body.username

    console.log(forgetEmail);

    const exisUser = await table.findOne({username : forgetEmail});

    if(exisUser)
    {
        const transporter = nodemailer.createTransport({
            service : "gmail",
            auth : {
                user : "faizsamjani999@gmail.com",
                pass : "smigtcgfaxkblzkn"
            }
        })
        const info = transporter.sendMail({
            from : "faizsamjani999@gmail.com",
            to : `${forgetEmail}`,
            subject : "Forgot Password",
            html : `${otp}`
        })

        
    }
    else
    {
        res.render("404");
    }
}

app.get("/sendotp",(req,res)=>{
    
    res.render("otpPage");
})

app.post("/sendotp",sendMail,(req,res)=>{
    
    res.redirect("/sendotp");
});




app.listen(port,()=>{
    console.log("Server Started At -",port);
})