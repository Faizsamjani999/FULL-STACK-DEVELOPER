const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');
const passport = require('passport');
const localStrategy = require('passport-local').Strategy;

route.get("/",indexController.signup);

route.get("/signin",indexController.signin);

route.post("/signin",indexController.signupPost);

route.post("/index",passport.authenticate('local'),indexController.signinPost);

route.get("/forgot_password",indexController.forgotPassword);




module.exports = route;