const mongoose = require('mongoose');

const schema = mongoose.Schema({
    project : {
        type : String,
        require : true
    },
    date : {
        type : String,
        require : true
    },
    section : {
        type : String,
        require : true
    },
    comments : {
        type : String,
        require : true
    },
    dec : {
        type : String,
        require : true
    },
    image : {
        type : String,
        require : true
    }
})

const table = mongoose.model("Table-1",schema);

module.exports = table;