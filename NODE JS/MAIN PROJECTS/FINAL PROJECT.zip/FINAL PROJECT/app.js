const express = require('express');
const port = 9999;
const app = express();
const path = require('path');
const database = require('./config/database');
const adminSchema = require('./model/adminSchema');
const userSchema = require('./model/userSchema');

app.use(express.urlencoded());
app.use(express.static(path.join(__dirname,"public")));

const session = require('express-session');
app.use(session({secret : "private-key"}));
const passport = require('passport');
app.use(passport.initialize());
app.use(passport.session());
const localauth = require('./middleware/localauth');
localauth(passport);

const flash = require('connect-flash');
app.use(flash());

app.set("view engine","ejs");

app.use(require('./routes/route'));

app.listen(port,()=>{
    console.log("Server Started At -",port);
})