const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');
const passport = require('passport');
const localStrategy = require('passport-local').Strategy;

route.get("/",indexController.homepage);

// Admin Sign Up - Sign In Started

route.get("/adminBlank",indexController.adminBlank);

route.get("/adminRegister",indexController.adminRegister);

route.get("/adminLogin",indexController.adminLogin);

route.post("/adminRegisterForm",indexController.adminRegisterPost);

route.post("/adminLoginForm",passport.authenticate('local'),indexController.adminLoginPost);

route.get("/adminLoginGet",indexController.adminLoginGet);

route.get("/adminProfile",indexController.adminProfile);

// Admin Sign Up - Sign In Over

// User Sign Up - Sign In Started

route.get("/userBlank",indexController.userBlank);

route.get("/userRegister",indexController.userRegister);

route.get("/userLogin",indexController.userLogin);

route.post("/userRegisterForm",indexController.userRegisterPost);

route.post("/userLoginForm",indexController.userLoginPost);

route.get("/forgotPasswordForm",indexController.forgotPassword);

route.post("/otpSend",indexController.sendMail);

route.post("/otpMatch",indexController.otpMatch);

// User Sign Up - Sign In Over

module.exports = route;