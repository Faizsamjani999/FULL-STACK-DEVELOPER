const adminSchema = require("../model/adminSchema");
const userSchema = require("../model/userSchema");
const nodemailer = require('nodemailer');

const homepage = (req,res)=>{
    res.render("homepage");
}

// Admin Sign Up - Sign In Started

const adminBlank = (req,res)=>{
    res.render("adminBlank");
}
const adminRegister = (req,res)=>{
    res.render("adminRegister");
}
const adminLogin = (req,res)=>{
    res.render("adminLogin",{
        adminMsg : req.flash("adminMsg")
    });
}
const adminRegisterPost = async(req,res)=>{
    await adminSchema.create(req.body);

    req.flash("adminMsg","Admin Register Successfully...");
    res.redirect('/adminLogin');
}
const adminLoginPost = (req,res)=>{
    res.render("adminPanel");
}
const adminLoginGet = (req,res)=>{
    res.render("adminPanel");
}
const adminProfile = (req,res)=>{
    res.render("adminProfile");
}

// Admin Sign Up - Sign In Over


// User Sign Up - Sign In Started

const userBlank = (req,res)=>{
    res.render("userBlank");
}
const userRegister = (req,res)=>{
    res.render("userRegister");
}
const userRegisterPost = async(req,res)=>{
    await userSchema.create(req.body);

    res.redirect("/userLogin");
}
const userLogin = (req,res)=>{
    res.render("userLogin");
}
const userLoginPost = async(req,res)=>{
    const existingUser = await userSchema.findOne({email : req.body.email});

    if(existingUser)
    {
        if(existingUser.password == req.body.password)
        {
            res.render("index");
        }
        else
        {
            res.render("wrongPassword");
        }
    }
    else
    {
        res.render("404");
    }
}

const forgotPassword = (req,res)=>{
    res.render("forgotPassword");
}

const otp = Math.floor(Math.random()*1000000);

const otpPage = (req,res)=>{
    res.render("otp",{
        errorMsg : req.flash("errorMsg")
    });
}

const sendMail = async(req,res)=>{
    const user = await userSchema.findOne({email : req.body.email});

    if(!user)
    {
        res.render("404");
    }
    else
    {
        const transporter = nodemailer.createTransport({
            service : "gmail",
            auth : {
                user : "faizsamjani999@gmail.com",
                pass : "qyhlcmckajfyaosv"
            }
        })

        const info = transporter.sendMail({
            from : "faizsamjani999@gmail.com",
            to : req.body.email,
            subject : "RTO Application Forgot Password OTP",
            html : `${otp}`
        })

        res.redirect("/otpPage");

    }
}



const otpMatch = (req,res)=>{
    const otp1 = req.body.otp1;
    const otp2 = req.body.otp2;
    const otp3 = req.body.otp3;
    const otp4 = req.body.otp4;
    const otp5 = req.body.otp5;
    const otp6 = req.body.otp6;

    const token = otp1+otp2+otp3+otp4+otp5+otp6

    console.log(token);

    if(token == otp)
    {
        res.redirect("/otpAndPassword");
    }
    else{
        req.flash("errorMsg","Wrong OTP....");
        res.redirect("back");
    }
}

const otpAndPassword = (req,res)=>{
    res.render("otpAndPassword",{
        passwordErr : req.flash("passwordErr")
    });
}

const otpMatchAndPassword = async(req,res)=>{
    const password = req.body.password;
    
    const existingEmail = await userSchema.findOne({email : req.body.email});

    if(existingEmail)
        {
            const id = existingEmail.id;

            await userSchema.findByIdAndUpdate(id,{
                password : password
            })

            res.redirect("/userLogin");
        }
        else{
            req.flash("passwordErr","Email is Not Matched in Our Data...")
            res.redirect("back");
        }
}

// User Sign Up - Sign In Over


module.exports = {
    homepage,
    adminBlank,
    adminRegister,
    adminLogin,
    adminRegisterPost,
    adminLoginPost,
    adminLoginGet,
    adminProfile,
    userBlank,
    userRegister,
    userRegisterPost,
    userLogin,
    userLoginPost,
    forgotPassword,
    otpPage,
    sendMail,
    otpMatch,
    otpAndPassword,
    otpMatchAndPassword
}