const express = require('express');

const port = 8888;

const app = express();

const path = require('path');

app.use('/',express.static(path.join(__dirname,"public")));

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index");
})
app.get("/about.html",(req,res)=>{
    res.render("about");
})
app.get("/blog-single.html",(req,res)=>{
    res.render("blog-single");
})
app.get("/blog.html",(req,res)=>{
    res.render("blog");
})
app.get("/contact.html",(req,res)=>{
    res.render("contact");
})
app.get("/portfolio-details.html",(req,res)=>{
    res.render("portfolio-details");
})
app.get("/portfolio.html",(req,res)=>{
    res.render("portfolio");
})
app.get("/pricing.html",(req,res)=>{
    res.render("pricing");
})
app.get("/services.html",(req,res)=>{
    res.render("services");
})
app.get("/team.html",(req,res)=>{
    res.render("team");
})
app.get("/testimonials.html",(req,res)=>{
    res.render("testimonials");
})

app.listen(port,()=>{
    console.log("Server Started At = "+ port);
})