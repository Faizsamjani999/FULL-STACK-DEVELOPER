const express = require('express');

const port = 8888;

const app = express();

const path = require('path');

app.use("/",express.static(path.join(__dirname,"public")))

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index");
})

app.get("/blog.html",(req,res)=>{
    res.render("blog");
})
app.get("/cart.html",(req,res)=>{
    res.render("cart");
})
app.get("/contact.html",(req,res)=>{
    res.render("contact");
})
app.get("/login.html",(req,res)=>{
    res.render("login");
})
app.get("/men.html",(req,res)=>{
    res.render("men");
})
app.get("/product-detail.html",(req,res)=>{
    res.render("product-detail");
})

app.listen(port,(req,res)=>{
    console.log("Server Started At = "+ port);
})