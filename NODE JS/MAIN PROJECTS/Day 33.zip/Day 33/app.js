const express = require('express');
const port = 9999;
const app = express();
const path = require('path');
const database = require('./config/database');
const table = require('./model/schema');
const nodemailer = require('nodemailer');
const otp = Math.floor(Math.random()*10000);
app.use(express.urlencoded());

const session = require('express-session');
app.use(session({secret : "private-key"}));
const passport = require('passport');
app.use(passport.initialize());
app.use(passport.session());
const localauth = require('./middleware/localauth');
localauth(passport);

const flash = require('connect-flash');
app.use(flash());

app.use(express.static(path.join(__dirname,"public")));

app.set("view engine","ejs");

const sendMail = async(req,res)=>{

    req.flash("msg","OTP Send To Your Email Address");
    
    console.log("Forget Email" + req.body.username);

    const user = await table.findOne({username : req.body.username});

    if(!user)
    {
        res.render("404");
    }
    else
    {
        const transporter = nodemailer.createTransport({
            service : "gmail",
            auth : {
                user : "faizsamjani999@gmail.com",
                pass : "caolbrmsaqrautom"
            }
        })

        const info = transporter.sendMail({
            from : "faizsamjani999@gmail.com",
            to : req.body.username,
            subject : "Forgot Password OTP",
            html : `${otp}`
        })

        res.redirect("/otp");
    }

    
}

app.post('/otp',sendMail);

app.get("/otp",(req,res)=>{
    res.render("otp",{
        msg : req.flash("msg")
    });
})

const verify = async(req,res)=>{
    const token = req.body.otp;
    const username = req.body.username;
    
    if(token == otp)
    {
        const exitUser = await table.findOne({username : username})

        const id = exitUser.id;

        const newPassword = req.body.password;

        await table.findByIdAndUpdate(id,{
            password : newPassword
        })

        res.redirect("/login");
    }
    else
    {
        res.redirect("/");
    }

    
}

app.post("/changepassword",verify);


app.use(require('./routes/route'));

app.listen(port,()=>{
    console.log("Server Started At -",port);
})