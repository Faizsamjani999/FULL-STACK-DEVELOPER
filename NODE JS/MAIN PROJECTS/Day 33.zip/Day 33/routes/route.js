const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');
const passport = require('passport');
const sendMail = require('../middleware/otp');
const localStrategy = require('passport-local').Strategy



route.get("/",indexController.register);

route.post("/login",indexController.registerPost);

route.get("/login",indexController.login);

route.post("/index",passport.authenticate('local'),indexController.index)

route.get("/forgot",indexController.forgot);



module.exports = route