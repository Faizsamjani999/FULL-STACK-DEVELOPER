const table = require("../model/schema");

const register = (req,res)=>{
    res.render("register");
}
const registerPost = (req,res)=>{
    table.create(req.body);
    res.redirect("/login");
}
const login = (req,res)=>{
    res.render("login");
}
const index = (req,res)=>{
    res.render("index");
}

const forgot = (req,res)=>{
    res.render("forgot");
}
const otp = (req,res)=>{
    res.render("otp");
}

module.exports = {
    register,
    registerPost,
    login,
    index,
    forgot,
    otp
}