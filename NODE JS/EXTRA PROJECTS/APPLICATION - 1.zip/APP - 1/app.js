const express = require('express');
const port = 9999;
const app = express();
const path = require('path');
const database = require("./config/database");
const adminTable = require("./model/adminSchema");
const jobTable = require("./model/jobSchema");

app.use(express.urlencoded());

const session = require('express-session');
app.use(session({secret:"private-key"}));
const passport = require('passport');
app.use(passport.initialize());
app.use(passport.session());
const localauth = require('./middleware/localauth');
localauth(passport);

app.set("view engine","ejs");

app.use(express.static(path.join(__dirname,"public")));
app.use(express.static(path.join(__dirname,"public2")));
app.use(express.static(path.join(__dirname,"upload")));

app.use(require("./routes/route"));

app.post("/adminLogin",passport.authenticate('local'),(req,res)=>{
    res.render("adminIndex");
})

app.listen(port,()=>{
    console.log("Server Started At - ",port);
})