const express = require('express');
const adminTable = require('../model/adminSchema');
const jobTable = require('../model/jobSchema');
const path = require('path');

const askingPage = (req,res)=>{
    res.render("askingPage");
}
// Admin Side Process

const adminReg = (req,res)=>{
    res.render("adminReg");
}

const adminSend = (req,res)=>{
    adminTable.create(req.body);
    console.log(req.body);
    res.redirect("adminReg");
}

const adminLogin = (req,res)=>{
    res.render("adminLogin");
}
const adminIndexGet = (req,res)=>{
    jobTable.find({}).then((allresult)=>{
        res.render("adminIndex",{
            result : allresult
        })
    })
}
const jobPosting = (req,res)=>{
    res.render("jobPosting");
}
const jobDataAdd = (req,res)=>{
    jobTable.create({
        jobtitle : req.body.jobtitle,
        companyname : req.body.companyname,
        salary : req.body.salary,
        des : req.body.des,
        skill : req.body.skill,
        education : req.body.education,
        exp : req.body.exp,
        vac : req.body.vac,
        nature : req.body.nature,
        date : req.body.date,
        logo : req.file.logo,
    }).then(()=>{
        console.log("Inserted");
        res.redirect("jobPosting");
    })
    
}



module.exports = {
    askingPage,
    adminReg,
    adminSend,
    adminLogin,
    adminIndexGet,
    jobPosting,
    jobDataAdd
    
}