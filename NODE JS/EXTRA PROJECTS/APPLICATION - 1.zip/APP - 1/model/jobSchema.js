const mongoose = require('mongoose');

const schema = mongoose.Schema({
    jobtitle : {
        type : String,
        require : true
    },
    companyname : {
        type : String,
        require : true
    },
    salary : {
        type : String,
        require : true
    },
    des : {
        type : String,
        require : true
    },
    skill : {
        type : String,
        require : true
    },
    education : {
        type : String,
        require : true
    },
    exp : {
        type : String,
        require : true
    },
    vac : {
        type : String,
        require : true
    },
    nature : {
        type : String,
        require : true
    },
    date : {
        type : String,
        require : true
    },
    logo : {
        type : String,
        require : true
    }
})

const jobTable = mongoose.model("jobtable",schema);

module.exports = jobTable;