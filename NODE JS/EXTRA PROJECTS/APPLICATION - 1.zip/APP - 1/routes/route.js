const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');

const multer = require('multer');

const storage = multer.diskStorage({
    destination:((req,res,cb)=>{
        cb(null,"upload/");
    }),
    filename : ((req,file,cb)=>{
        cb(null,file.originalname);
    })
})

const upload = multer({storage : storage}).single('logo');

route.get("/",indexController.askingPage);

route.get("/adminReg",indexController.adminReg);

route.post("/adminSend",indexController.adminSend);

route.get("/adminLogin",indexController.adminLogin);

route.get("/adminIndexGet",indexController.adminIndexGet);

route.get("/jobPosting",indexController.jobPosting);

route.post("/jobadd",upload,indexController.jobDataAdd);

module.exports = route;