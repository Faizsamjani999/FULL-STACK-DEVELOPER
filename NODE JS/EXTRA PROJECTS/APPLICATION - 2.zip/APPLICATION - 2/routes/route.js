const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');
const passport = require('passport');
const localStrategy = require('passport-local').Strategy;

const multer = require('multer');

const storage = multer.diskStorage({
    destination : ((req,res,cb)=>{
        cb(null,"upload/");
    }),
    filename : ((req,file,cb)=>{
        cb(null,file.originalname);
    })
})

const upload = multer({storage : storage}).single("img");

route.get("/",indexController.signup);

route.post("/signup",indexController.signupForm);

route.get("/signin",indexController.signin);

route.post("/login",passport.authenticate('local'),indexController.login);

route.get("/login",indexController.login);

route.get("/forgotpassword",indexController.forgotPassword);

route.post("/changingPassword",indexController.changepassword);

route.post("/insert",upload,indexController.insert);

route.get("/view",indexController.view);

route.get("/delete",indexController.deleted);

route.get("/edit",indexController.edit);

route.post("/update",upload,indexController.update);



module.exports = route;