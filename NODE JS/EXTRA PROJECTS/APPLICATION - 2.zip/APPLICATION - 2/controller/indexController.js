const express = require('express');
const table = require('../model/schema');
const passport = require('passport');
const foodTable = require('../model/schema2');
const path = require('path');
const fs = require('fs');
const localStrategy = require('passport-local').Strategy

const signup = (req,res)=>{
    res.render("signup");
}

const signupForm = async(req,res)=>{
    const data = req.body;

    const existingUser = await table.findOne({username : data.username});

    if(existingUser)
    {
        res.render("alreadyExist");
    }
    else{
        table.create(data);
        res.render("signin");
    }

    
}
const signin = (req,res)=>{
    res.render("signin");
}
const login = (req,res)=>{
    res.render("index",{
        info : req.flash("msg")
    });
}

const forgotPassword = (req,res)=>{
    res.render("forgot");
}

const changepassword = async(req,res)=>{
    const changingData = req.body;

    const change = await table.findOne({username : changingData.username});

    if(change)
    {
        change.password = changingData.password;

        table.create(change).then(()=>{
            res.render("signin");
        })
    }
    else{
        res.render("404");
    }
}


const insert = (req,res)=>{
    foodTable.create({
        name : req.body.name,
        email : req.body.email,
        phone : req.body.phone,
        noofpersons : req.body.noofpersons,
        date : req.body.date,
        time : req.body.time,
        preferredfood : req.body.preferredfood,
        occasion : req.body.occasion,
        itemname : req.body.itemname,
        price : req.body.price,
        city : req.body.city,
        img : req.file.path
    }).then(()=>{
        console.log("Inserted");
        req.flash("msg","Your Food Item Added Successfully...");
        res.redirect("/login");
        console.log(req.body);
    })
}

const view = (req,res)=>{
    foodTable.find({}).then((allresult)=>{
        res.render("viewOrder",{
            result : allresult
        });
    })
}
const deleted = (req,res)=>{
    let id = req.query.id;

    foodTable.findById(id).then((record)=>{
        fs.unlinkSync(record.img);
    })

    foodTable.findByIdAndDelete(id).then(()=>{
        res.redirect("/view");
    })
}
const edit = (req,res)=>{
    let id = req.query.id;

    foodTable.findById(id).then((allresult)=>{
        res.render("edit",{
            result : allresult
        })
    })
}
const update = (req,res)=>{
    let id = req.body.id;

    if(req.file)
    {
        var obj = {
            name : req.body.name,
            email : req.body.email,
            phone : req.body.phone,
            noofpersons : req.body.noofpersons,
            date : req.body.date,
            time : req.body.time,
            preferredfood : req.body.preferredfood,
            occasion : req.body.occasion,
            itemname : req.body.itemname,
            price : req.body.price,
            city : req.body.city,
            img : req.file.path
        }
    }
    else{
        var obj = {
            name : req.body.name,
            email : req.body.email,
            phone : req.body.phone,
            noofpersons : req.body.noofpersons,
            date : req.body.date,
            time : req.body.time,
            preferredfood : req.body.preferredfood,
            occasion : req.body.occasion,
            itemname : req.body.itemname,
            price : req.body.price,
            city : req.body.city
        }
    }

    foodTable.findById(id).then((record)=>{
        fs.unlinkSync(record.img);
    }) 

    foodTable.findByIdAndUpdate(id,obj).then(()=>{
        res.redirect("/view");
    })
}


module.exports = {
    signup,
    signupForm,
    signin,
    login,
    forgotPassword,
    changepassword,
    insert,
    view,
    deleted,
    edit,
    update
}