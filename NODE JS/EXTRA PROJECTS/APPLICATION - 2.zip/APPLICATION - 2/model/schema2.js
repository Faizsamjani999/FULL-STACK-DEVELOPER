const mongoose = require('mongoose');

const schema = mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email : {
        type : String,
        required : true
    },
    phone : {
        type : String,
        required : true
    },
    noofpersons : {
        type : String,
        required : true
    },
    date : {
        type : String,
        required : true
    },
    time : {
        type : String,
        required : true
    },
    preferredfood : {
        type : String,
        required : true
    },
    occasion : {
        type : String,
        required : true
    },
    itemname : {
        type : String,
        required : true
    },
    price : {
        type : String,
        required : true
    },
    city : {
        type : String,
        required : true
    },
    img : {
        type : String,
        required : true
    }
})

const foodTable = mongoose.model("food",schema);

module.exports = foodTable;