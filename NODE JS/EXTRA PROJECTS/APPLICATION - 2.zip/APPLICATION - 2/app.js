const express = require('express');
const port = 9999;
const app = express();
const path = require('path');
const database = require('./config/database');
const table = require("./model/schema");
const foodTable = require("./model/schema2");




app.use(express.urlencoded());
const session = require('express-session');
app.use(session({secret : "private-key"}));
const passport = require('passport');
app.use(passport.initialize());
app.use(passport.session());
const localauth = require('./middleware/localauth');
localauth(passport);
const flash = require('connect-flash');
app.use(flash());


app.set("view engine","ejs");
app.use(express.static(path.join(__dirname,"public")));
app.use("/upload",express.static(path.join(__dirname,"upload")));

app.use(require('.//routes/route'));

app.listen(port,()=>{
    console.log("Server Started At",port);
})