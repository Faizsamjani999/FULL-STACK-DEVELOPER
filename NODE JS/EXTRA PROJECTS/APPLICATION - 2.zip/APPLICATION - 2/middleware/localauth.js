const localStrategy = require('passport-local').Strategy
const table = require('../model/schema');

const localauth = (passport)=>{
    passport.use(new localStrategy(async(username,password,done)=>{
        const user = await table.findOne({username : username});

        if(!user)
        {
            return done(null,false);
        }
        if(user.password != password)
        {
            return done(null,false);
        }
        return done(null,user);
    })
)

passport.serializeUser((user,done)=>{
    return done(null,done);
})
passport.deserializeUser(async(id,done)=>{
    const user = await table.findById(id);
    return done(null,user);
})

}

module.exports = localauth