const express = require('express');

const port = 8888;

const app = express();

app.use(express.urlencoded());

let menu = [
    {
        no : 1,
        customer : "M.Faiz Samjani",
        name : "Pizza",
        price : 250,
        qun : 2,
        cgst : "",
        sgst : "",
        amt : " ",
        location : "Imperial Palace Rajkot -",
        number : +91-4654546546
    },
    {
        no : 2,
        customer : "M.Faiz Samjani",
        name : "Sandwich",
        price : 140,
        qun : 2,
        cgst : "",
        sgst : "",
        amt : " ",
        location : "Imperial Palace Rajkot -",
        number : +91-4654546546
    },
    {
        no : 3,
        customer : "M.Faiz Samjani",
        name : "Burger",
        price : 120,
        qun : 2,
        cgst : "",
        sgst : "",
        amt : " ",
        location : "Imperial Palace Rajkot -",
        number : +91-4654546546
    }
    
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        menuDetail : menu
    });
})

app.post("/insert",(req,res)=>{
    console.log(req.body);

    let no = req.body.no;
    let customer = req.body.customer;
    let name = req.body.name;
    let price = req.body.price;
    let qun = req.body.qun;
    let location = req.body.location;
    let number = req.body.number;

    let obj = {
        no : no,
        customer : customer,
        name : name,
        price : price,
        qun : qun,
        location : location,
        number : number
    }

    menu.push(obj);
    res.redirect("back");
})



app.get("/delete",(req,res)=>{
    let no = req.query.no;

    let ans = menu.filter((val)=>{
        return val.no != no;
    })
    menu = ans;
    res.redirect("back");
})

app.get("/edit",(req,res)=>{
    let no = req.query.no;

    let editData = menu.filter((val)=>{
        return val.no == no;
    })
    res.render("edit",{
        editAns : editData[0]
    })
})

app.post("/update",(req,res)=>{
    let no = req.body.no;

    let ans = menu.filter((val)=>{
        if(val.no == no){
            val.customer = req.body.customer;
            val.name = req.body.name;
            val.price = req.body.price;
            val.qun = req.body.qun;
            val.location = req.body.location;
            val.number = req.body.number;

        }
        return val;
    })
    menu = ans;

    res.redirect("/");
})

app.get("/order",(req,res)=>{
    let no = req.query.no;
    
    let orderData = menu.filter((val)=>{
         return val.no == no;
    })
    let gst = orderData.filter((val)=>{
        if(val.no == no)
        {
            val.cgst = val.price * 10 / 100 * val.qun;
            val.sgst = val.price * 8 / 100 * val.qun;
            val.amt = val.price * val.qun + val.cgst + val.sgst;
        }
        return val;
    })
    
    res.render("order",{
        orderItem : gst[0]
    })
    
})

app.listen(port,()=>{
    console.log("Server Started At = ",port);
})