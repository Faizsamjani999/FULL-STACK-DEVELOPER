const express = require('express');
const port = 9999;
const app = express();

app.use(express.urlencoded());

let data = [
    {
        no : 1,
        task : "Anything"
    }
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        allData : data
    })
})
app.post("/insert",(req,res)=>{
    console.log(req.body);

    let no = req.body.no;
    let task = req.body.task;

    let obj = {
        no : no,
        task : task
    }

    data.push(obj);
    res.redirect("back");
})
app.get("/delete",(req,res)=>{
    let no = req.query.no;

    let ans = data.filter((val)=>{
        return val.no != no;
    })

    data = ans;

    res.redirect("back");
})

app.get("/edit",(req,res)=>{
    let no = req.query.no;

    let editAns = data.filter((val)=>{
        return val.no == no;
    })
    res.render("edit",{
        editData : editAns[0]
    })
})
app.post("/update",(req,res)=>{
    let no = req.body.no;

     let ans = data.filter((val)=>{
        if(val.no == no)
        {
            val.task = req.body.task;
        }
        return val;
    })
    data = ans;
    res.redirect("/");
})

app.listen(port,()=>{
    console.log("Server Started At = " + port);
})