const express = require('express');

const port = 8888;

const app = express();

const path = require('path');

app.use("/",express.static(path.join(__dirname,"public")));

const breakpoint = (req,res,next) =>{
    if(req.query.email == "faiz999@gmail.com" || req.query.name == "faizsamjani")
    {
        return next()
    }
    else{
        res.end();
    }
}

app.set("view engine","ejs");


app.get("/",breakpoint,(req,res)=>{
    res.render("index");
})


app.listen(port,()=>{
    console.log("Server Started At = "+ port);
})