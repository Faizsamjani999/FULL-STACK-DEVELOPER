const express = require('express');     // step 1

const port = 8888;          // step 2

const app = express();      // step 3

app.use(express.urlencoded());

const data = [
    {
        
    }
]

const database = require('./config/database');   // step 5

const schema = require("./model/schema");       // step 13

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        allData : data
    });
})

app.post("/insert",(req,res)=>{
    let name = req.body.name;
    let surname = req.body.surname;
    let email = req.body.email;
    let number = req.body.number;
    let deg = req.body.deg;
    let password = req.body.password;

    let obj = {
        name : name,
        surname : surname,
        email : email,
        number : number,
        deg : deg,
        password : password
    }
    data.push(obj);
    res.redirect("back");
})

app.listen(port,()=>{           // step 4
    console.log("Server Started At - "+ port);
})