const mongoose = require('mongoose'); // step 5

mongoose.connect('mongodb://127.0.0.1/MyDatabase');     //step 6

const db = mongoose.connection;     // step 7

db.on('connected',(err)=>{      // step 8
    if(err)
    {
        console.log("Database Not Connected...");
    }
    else
    {
        console.log("Database Connected Successfully...");
    }
})