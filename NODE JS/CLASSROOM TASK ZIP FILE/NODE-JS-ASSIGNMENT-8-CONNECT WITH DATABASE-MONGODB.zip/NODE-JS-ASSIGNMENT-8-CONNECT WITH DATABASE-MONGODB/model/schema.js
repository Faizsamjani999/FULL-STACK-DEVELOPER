const mongoose = require('mongoose');       // step 9

const studentSchema = mongoose.Schema({     // step 10
        name : {
            type : String,
            require : true
        },
        surname :{
            type : String,
            require : true
        },
        email : {
            type : String,
            require : true
        },
        number : {
            type : Number,
            require : true
        },
        deg : {
            type : String,
            require : true
        },
        password : {
            type : String,
            require : true
        }
        
})

const schema = mongoose.model("schema",studentSchema);      // step 11

module.exports=schema;      // step 12