console.log(__dirname);

// that means in console log we can write __dirname

// and in terminal we can run code with node filename.js

// so in the result we can give full path of file but not comes file name