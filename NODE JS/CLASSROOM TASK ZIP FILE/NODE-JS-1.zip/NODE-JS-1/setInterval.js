var time = 0;

var result = setInterval(() => {
    time += 2;
    console.log(time);
}, 2000);

