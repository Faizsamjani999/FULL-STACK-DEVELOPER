show = () =>{
    console.log("We Are Complete Our javascript");
    console.log("And then We can start learning Node JS");
}

show();

setTimeout(show,2000);