console.log(__filename);

// that means in console log we can write __filename

// and in terminal we can run code with node filename.js

// so in the result we can give full path with file name