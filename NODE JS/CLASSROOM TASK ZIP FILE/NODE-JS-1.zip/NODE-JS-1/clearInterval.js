
var count = 0;



var table = setInterval(() => {
        count++;
        var dispaly = `${num} X ${count} = ${num*count}`
        console.log(dispaly);
        if(count == 10)
        {
            clearInterval(table);
        }
}, 2000);