const express = require('express');
const port = 9999;
const app = express();
app.use(express.urlencoded());

const studentData = [
    {
        grid : 5110,
        fname : "Mohammadfaiz",
        lname : "Samjani",
        email : "faizsamjani999@gmail.com",
        number : "9574357690",
        cource : "Full Stack Developer"
    }
]
app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        student : studentData
    });
})

app.post("/insert",(req,res)=>{
    console.log(req.body);

    let grid = req.body.grid;
    let fname = req.body.fname;
    let lname = req.body.lname;
    let email = req.body.email;
    let number = req.body.number;
    let cource = req.body.cource;

    let obj = {
        grid : grid,
        fname : fname,
        lname : lname,
        email : email,
        number : number,
        cource : cource
    }

    studentData.push(obj);
    res.redirect('back');
})





app.listen(port,(err)=>{
    if(err)
    {
        console.log("Server Not Started...");
    }
    else
    {
        console.log("Server Started..." + port);
    }
})