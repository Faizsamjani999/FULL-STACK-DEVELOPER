const express = require('express');

const port = 9999;

const app = express();

app.use(express.urlencoded());

const studentData = [
    {
        id : 1,
        name : "Mohammadfaiz",
        email : "faizsamjani999@gmail.com",
        password : 12345
    },
    {
        id : 2,
        name : "Mayank",
        email : "mk1515@gmail.com",
        password : 52525
    },
    {
        id : 3,
        name : "Baadi",
        email : "fbaadi420@gmail.com",
        password : 420420
    },
    {
        id : 4,
        name : "Rutul",
        email : "rl123@gmail.com",
        password : 10101
    },
    {
        id : 5,
        name : "Kirti",
        email : "ks456@gmail.com",
        password : 45454
    },
    {
        id : 6,
        name : "Radhika",
        email : "rgohel12@gmail.com",
        password : 45858
    },
    {
        id : 7,
        name : "Jagruti",
        email : "jagruti12@gmail.com",
        password : 47478
    },
    {
        id : 8,
        name : "Vidhi",
        email : "vidhi12345@gmail.com",
        password : 74747
    }
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        student : studentData
    });
})

app.listen(port,(err)=>{
    if(err)
    {
        console.log("Not Started Yet");
        return false;
    }
    else
    {
        console.log("Started Server..." + port);
    }
})