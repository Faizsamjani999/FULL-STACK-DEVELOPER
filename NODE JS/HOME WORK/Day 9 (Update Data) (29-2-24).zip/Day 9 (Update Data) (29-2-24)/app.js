const express = require('express'); //step 1
const port = 9999; // step 2 
const app = express(); // step 3
app.use(express.urlencoded()); //step 5
let employeData = [     //step 8
    {
        id : 1,
        name : "Mohammadfaiz",
        email : "fm@gmail.com",
        password : 12345
    }
]

app.set("view engine","ejs");   //step 6

app.get("/",(req,res)=>{        // step 7   VIEW
    res.render("index",{
        employe:employeData
    })
})

app.post("/insert",(req,res)=>{     //step 9    INSERT
    console.log(req.body);

    let id = req.body.id;
    let name = req.body.name;
    let email = req.body.email;
    let password = req.body.password;

    const obj = {
        id : id,
        name : name,
        email : email,
        password : password
    }

    employeData.push(obj);
    res.redirect('back');
})

app.get("/delete",(req,res)=>{      // step 10 DELETE
    let id = req.query.id;

    let ans = employeData.filter((val)=>{
        return val.id != id;
    })
    employeData = ans;
    res.redirect('back');
})

app.get('/edit',(req,res)=>{        // step 11 EDIT
    let id=req.query.id;
    
    let editItem=employeData.filter((val)=>{
        return val.id == id;
})
res.render('edit',{
    editData:editItem[0]
})   
})

app.post('/update',(req,res)=>{     // step 12 UPDATE
    let id=req.body.id;

    let ans=employeData.filter((val)=>{
        if(val.id=id){
            val.name = req.body.name;
            val.email = req.body.email;
            val.password = req.body.password;
        }
        return val;
    })
    employeData = ans;
    res.redirect('/');
})
app.listen(port,(err)=>{    //step 4
    if(err){
        console.log("Server Not Started...");
    }
    else{
        console.log("Server Started At = " + port);
    }
})