const mongoose = require('mongoose');

const dataSchema = mongoose.Schema({
    name : {
        type : String,
        require : true
    },
    email : {
        type : String,
        require : true
    },
    password : {
        type : String,
        require : true
    }
})

const schema = mongoose.model("schema",dataSchema);

module.exports = schema;