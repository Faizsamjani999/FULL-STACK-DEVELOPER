const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1/website1');

const db = mongoose.connection;

db.on('connected',(err)=>{
    if(err)
    {
        console.log("Database is Not Connected");
    }
    else{
        console.log("Database is Connected");
    }
})