const express = require('express');

const port = 9999;

const app = express();

app.use(express.urlencoded());
let data = [
    {
        name : "faiz"
    }
]

const database = require('./config/database');

const schema = require('./model/schema');

const path = require('path');

app.use("/",express.static(path.join(__dirname,"public")))

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index");
})

app.post("/insert",(req,res)=>{
    let name = req.body.name;
    let email = req.body.email;
    let pass = req.body.pass;
    let re_pass = req.body.re_pass;

    let obj = {
        name : name,
        email : email,
        pass : pass,
        re_pass : re_pass,
    }

    data.push(obj);
    res.render("login");
})

app.post("/check",(req,res)=>{
    let name = req.body.name;
    let pass = req.body.pass;
    

    let ans = data.filter((val)=>{
        if(name == "hello")
        {
            data = ans;
        }
        else
        {
            res.redirect("/");
        }
        return val;
    })
        
})

app.listen(port,()=>{
    console.log("Server Started -:"+port);
})