const intro = require('./local');

console.log(intro.name);
console.log(intro.surname);
console.log(intro.age);
console.log(intro.cource);
console.log(intro.number);
console.log(intro.address);
console.log(intro.city);
console.log(intro.pincode);