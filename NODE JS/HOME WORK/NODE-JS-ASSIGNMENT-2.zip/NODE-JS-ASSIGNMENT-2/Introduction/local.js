const intro = {
     name : "Mohammadfaiz",
     surname : "Samjani",
     age : 21,
     cource : "Full Stack Development",
     number : 9574357690,
     address : "Old Government Hospital,Near Bhagat Geat Road",
     city : "Vasavad",
     pincode : 364490
}

module.exports = intro;