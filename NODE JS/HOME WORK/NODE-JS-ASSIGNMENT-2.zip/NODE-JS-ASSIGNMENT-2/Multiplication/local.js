const multi ={
    into : function(){
        const a = 10;
        const b = 5;

        console.log("Multiplication of = ",a*b);
    }
}
module.exports = multi;