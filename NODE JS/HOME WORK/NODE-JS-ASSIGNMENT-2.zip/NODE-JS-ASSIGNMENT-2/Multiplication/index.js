const multi = require('./local')

console.log(multi.into());