const addition ={
    sum : function(){
        const a = 10;
        const b = 20;

        console.log("Addition of = ", a+b);
        // console.log(c);
    },
    sub:function(){
        const x = 100;
        const y = 50;

        console.log("Substraction of = ", x-y);
    }
}
module.exports = addition;  // export our module to main file

// const multi = {
//     into : function(){
//         const r = 20;
//         const d = 20;

//         console.log("Multiplication of = " , r*d);
//     }
// }
// module.exports = multi;