const all_attach = require('./local');  // local file access in index file with require function

console.log(all_attach.sum());

console.log(all_attach.sub());

// console.log(all_attach.into());