const div = {
    divi : function(){
        const a = 100;
        const b = 4;

        console.log("Divison of = ",a/b);
    }
}

module.exports = div;