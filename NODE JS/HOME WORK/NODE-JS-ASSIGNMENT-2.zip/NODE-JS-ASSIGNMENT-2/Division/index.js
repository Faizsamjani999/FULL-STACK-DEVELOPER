const div = require('./local');

console.log(div.divi());