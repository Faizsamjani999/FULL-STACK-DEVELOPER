const { log } = require('console');
const express = require('express');
const port = 8888;
const app = express();

app.use(express.urlencoded());

var list = [
    {
        no : 1,
        lec : "Node JS.",
        faculty : "Rupesh Sir",
        time : 10
    }
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        listItem : list
    })
})

app.post("/insert",(req,res)=>{
    console.log(req.body);
    let no = req.body.no;
    let lec = req.body.lec;
    let faculty = req.body.faculty;
    let time = req.body. time;

    let obj = {
        no : no,
        lec : lec,
        faculty : faculty,
        time : time
    }
    list.push(obj);
    res.redirect('back');
    
})
app.get("/delete",(req,res)=>{
    let no = req.query.no;

    let ans = list.filter((val)=>{
        return val.no != no;
    })
    list = ans;
    res.redirect('back');
})

app.get("/edit",(req,res)=>{
    let no=req.query.no;

    let editItem=list.filter((val)=>{
        return val.no == no
    })
    res.render('edit',{
        editData : editItem[0]
    })
})

app.post("/update",(req,res)=>{
    let no=req.body.no;

    let ans=list.filter((val)=>{
        if(val.no = no){
            val.lec = req.body.lec;
            val.faculty = req.body.faculty;
            val.time = req.body.time;
        }
        return val;
    })
    list = ans;
    res.redirect('/');
})

app.listen(port,(err)=>{
    if(err){
        console.log("Server Not Started");
    }
    else{
        console.log("Server Started At = ",port);
    }
})