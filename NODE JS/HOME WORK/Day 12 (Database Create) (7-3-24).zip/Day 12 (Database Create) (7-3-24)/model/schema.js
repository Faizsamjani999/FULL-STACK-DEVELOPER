const mongoose = require('mongoose');

const studentSchema = mongoose.Schema({
    name : {
        type : String,
        require : true
    },
    surname : {
        type : String,
        require : true
    },
    email : {
        type : String,
        require : true
    },
    password : {
        type : String,
        require : true
    }
})

const schema = mongoose.model("schema",studentSchema);

module.exports = schema;