const express = require('express');

const port = 8888;

const app = express();

const database = require('./config/database');

const schema = require('./model/schema');

let studentData = [
    {
        name : "M.Faiz",
        surname : "Samjani",
        email : "faiz999@gmail.com",
        password : "123"
    }
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        student : studentData
    });
})

app.post("/insert",(req,res)=>{
    console.log(req.body);
})



app.listen(port,()=>{
    console.log("Server Started At :- "+port);
})