const mongoose = require('mongoose'); // step 1 

mongoose.connect('mongodb://127.0.0.1/RNW'); // step 2

const db = mongoose.connection; // step 3

db.on('connected',(err)=>{
    if(err)
    {
        console.log("Database Not Connected");
        return false;
    }
    else
    {
        console.log("Database Connected...");
    }
})

module.exports = db;