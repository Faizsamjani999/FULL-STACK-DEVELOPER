const express = require('express');

const port = 9999;

const app = express();

app.use(express.urlencoded());

let studentData = [
    {
        id : 1,
        name : "Mohammadfaiz",
        email : "Samjani",
        password : "123"
    }
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        student : studentData
    });
})

app.post("/insert",(req,res)=>{
    console.log(req.body);

    let id = req.body.id;
    let name = req.body.name;
    let email = req.body.email;
    let password = req.body.password;

    const obj = {
        id : id,
        name : name,
        email : email,
        password : password
    }

    studentData.push(obj);
    res.redirect('back');
})

app.get("/delete",(req,res)=>{
    let id = req.query.id;

    let ans = studentData.filter((val)=>{
        return val.id != id;
    })

    studentData = ans;
    res.redirect('back');
})

// app.get("/edit",(res,req)=>{
//     let id = req.query.id;

//     let data = studentData.filter((val)=>{
//         return val.id == id;
//     })

//     res.render("edit",{
//         editData : data[0]
//     })


// })

app.get('/edit',(req,res)=>{
    let id=req.query.id;
    
    let editItem=studentData.filter((val)=>{
        return val.id == id;
})
res.render('edit',{
    editData:editItem[0]
})   

        })



app.listen(port,(err)=>{
    if(err)
    {
        console.log("Server Not Started...");
    }
    else
    {
        console.log("Server Started :-" + port);
    }
})