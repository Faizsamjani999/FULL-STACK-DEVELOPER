const http = require('http'); // Step 1

const port = 9999; // step 2

const fs = require('fs');                   // step 6

const requestHandler = (req,res) =>{            // step 5
    let fileName = " ";

    switch (req.url){
        case '/':
            fileName = "index.html";
            break;
        default :
            fileName = "index.html";
    }

    fs.readFile(fileName,(err,result)=>{
        if(!err)
        {                                                         // step 7
            res.end(result);
        }
    })
}

const server = http.createServer(requestHandler);                       // step 3

server.listen(port,(err)=>{
    if(err){
        console.log("Not Started...");                          // step 4
    }
    else
    {
        console.log("Started Successfully...");
    }
})

