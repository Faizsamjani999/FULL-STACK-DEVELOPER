const mongoose = require('mongoose');

const schema = mongoose.Schema({
    title : {
        type : String,
        require : true
    },
    actors : {
        type : String,
        require : true
    },
    awards : {
        type : String,
        require : true
    },
    boxoffice : {
        type : String,
        require : true
    },
    director : {
        type : String,
        require : true
    },
    category : {
        type : String,
        require : true
    },
    language : {
        type : String,
        require : true
    },
    release : {
        type : String,
        require : true
    },
    writer : {
        type : String,
        require : true
    },
    year : {
        type : String,
        require : true
    },
    rating : {
        type : String,
        require : true
    },
    country : {
        type : String,
        require : true
    },
    poster : {
        type : String,
        require : true
    }
})

const data = mongoose.model("Movie",schema);

module.exports = data;