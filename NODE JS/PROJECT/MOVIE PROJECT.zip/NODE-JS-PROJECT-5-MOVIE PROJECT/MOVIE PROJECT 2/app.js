const express = require('express');
const port = 7860;
const app = express();
const path = require('path');

const database = require('./config/database');
const data = require('./model/schema');

app.use(express.urlencoded());
app.use("/upload",express.static(path.join(__dirname,"upload")));
app.set("view engine","ejs");

app.use("/",require('./routes/route'));
app.use("/",express.static(path.join(__dirname,"public")));

app.listen(port,()=>{
    console.log("Server Started At = ",port);
})
