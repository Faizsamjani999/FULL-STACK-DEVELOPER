const express = require('express');
const data = require('../model/schema');
const path = require('path');
const fs = require('fs');

const index = (req,res)=>{
    res.render("index");
}
const insert = (req,res)=>{
    data.create({
        title : req.body.title,
        actors : req.body.actors,
        awards : req.body.awards,
        boxoffice : req.body.boxoffice,
        director : req.body.director,
        category : req.body.category,
        language : req.body.language,
        release : req.body.release,
        writer : req.body.writer,
        year : req.body.year,
        rating : req.body.rating,
        country : req.body.country,
        poster : req.file.path
    }).then(()=>{
        console.log("Insert...");
        res.redirect("/insert");
    })
}

const result = (req,res)=>{
    data.find({}).then((alldata)=>{
        res.render("result",{
            data : alldata
        });
    })
}

const deleted = (req,res)=>{
    let id = req.query.id;

    data.findById(id).then((alldata)=>{
        fs.unlinkSync(alldata.poster);
    })

    data.findByIdAndDelete(id).then(()=>{
        res.redirect("/insert");
    })
}
const edit = (req,res)=>{
    let id = req.query.id;

    data.findById(id).then((alldata)=>{
        res.render("edit",{
            data : alldata
        })
    })
}
const update = (req,res)=>{
    let id = req.body.id;

    if(req.file)
    {
        var obj = {
            title : req.body.title,
            actors : req.body.actors,
            awards : req.body.awards,
            boxoffice : req.body.boxoffice,
            director : req.body.director,
            category : req.body.category,
            language : req.body.language,
            release : req.body.release,
            writer : req.body.writer,
            year : req.body.year,
            rating : req.body.rating,
            country : req.body.country,
            poster : req.file.path
        }
    }
    else
    {
        var obj = {
            title : req.body.title,
            actors : req.body.actors,
            awards : req.body.awards,
            boxoffice : req.body.boxoffice,
            director : req.body.director,
            category : req.body.category,
            language : req.body.language,
            release : req.body.release,
            writer : req.body.writer,
            year : req.body.year,
            rating : req.body.rating,
            country : req.body.country
        }
    }

    data.findById(id).then((alldata)=>{
        fs.unlinkSync(alldata.poster);
    })

    data.findByIdAndUpdate(id,obj).then(()=>{
        res.redirect("/insert");
    })
}

module.exports = {
    index,
    insert,
    result,
    deleted,
    edit,
    update
}