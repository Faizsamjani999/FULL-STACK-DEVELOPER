const mongoose = require('mongoose');

const schema = mongoose.Schema({
    moviename : {
        type : String,
        require : true
    },
    category : {
        type : String,
        require : true
    },
    actor : {
        type : String,
        require : true
    },
    actress : {
        type : String,
        require : true
    },
    hit : {
        type : String,
        require : true
    },
    income : {
        type : String,
        require : true
    },
    imdb : {
        type : String,
        require : true
    },
    sucorfail : {
        type : String,
        require : true
    },
    image : {
        type : String,
        require : true
    }
})

const data = mongoose.model("MOVIE",schema);

module.exports = data;