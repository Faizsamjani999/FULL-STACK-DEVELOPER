const express = require('express');
const data = require('../model/schema');
const path = require('path');
const fs = require('fs');

const index = (req,res)=>{
    res.render('index');
}
const insert = (req,res)=>{
    data.create({
        moviename : req.body.moviename,
        category : req.body.category,
        actor : req.body.actor,
        actress : req.body.actress,
        hit : req.body.hit,
        income : req.body.income,
        imdb : req.body.imdb,
        sucorfail : req.body.sucorfail,
        image : req.file.path
    }).then(()=>{
        console.log("Insert...");
        res.redirect('insert');
    })
}
const result = (req,res)=>{
    data.find({}).then((alldata)=>{
        res.render('result',{
            data : alldata
        })
    })
}
const deleted = (req,res)=>{
    let id = req.query.id;

    data.findById(id).then((alldata)=>{
        fs.unlinkSync(alldata.image)
    })

    data.findByIdAndDelete(id).then(()=>{
        res.redirect("/insert");
    })
}
const edit = (req,res)=>{
    let id = req.query.id;

    data.findById(id).then((alldata)=>{
        res.render("edit",{
            data : alldata
        })
    })
}
const update = (req,res)=>{
    let id = req.body.id;

    if(req.file)
    {
        var obj = {
            moviename : req.body.moviename,
            category : req.body.category,
            actor : req.body.actor,
            actress : req.body.actress,
            hit : req.body.hit,
            income : req.body.income,
            imdb : req.body.imdb,
            sucorfail : req.body.sucorfail,
            image : req.file.path
        }
    }
    else{
        var obj = {
            moviename : req.body.moviename,
            category : req.body.category,
            actor : req.body.actor,
            actress : req.body.actress,
            hit : req.body.hit,
            income : req.body.income,
            imdb : req.body.imdb,
            sucorfail : req.body.sucorfail
        }
    }

    data.findById(id).then((alldata)=>{
        fs.unlinkSync(alldata.image)
    })

    data.findByIdAndUpdate(id,obj).then(()=>{
        console.log("Updated...");
        res.redirect("/insert");
    })
}
module.exports = {
    index,
    insert,
    result,
    deleted,
    edit,
    update
}