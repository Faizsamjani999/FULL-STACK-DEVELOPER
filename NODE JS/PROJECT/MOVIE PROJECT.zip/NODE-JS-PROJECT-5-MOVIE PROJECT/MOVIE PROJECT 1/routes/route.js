const express = require('express');

const route = express.Router();

const multer = require('multer');

const storage = multer.diskStorage({
    destination : ((req,res,cb)=>{
        cb(null,'upload/');
    }),
    filename : ((req,file,cb)=>{
        cb(null,file.originalname);
    })
})

const upload = multer({storage : storage}).single('image');

const indexController = require('../controller/indexController');

route.get("/",indexController.index);

route.post("/insert",upload,indexController.insert);

route.get("/insert",indexController.result);

route.get("/delete",indexController.deleted);

route.get("/edit",indexController.edit);

route.post("/update",upload,indexController.update);

module.exports = route;