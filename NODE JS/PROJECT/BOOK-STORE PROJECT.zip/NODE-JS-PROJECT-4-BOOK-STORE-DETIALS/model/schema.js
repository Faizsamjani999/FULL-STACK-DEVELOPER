const mongoose = require('mongoose');

const bookSchema = mongoose.Schema({
    bookname : {
        type : String,
        require : true
    },
    author : {
        type : String,
        require : true
    },
    company : {
        type : String,
        require : true
    },
    email : {
        type : String,
        require : true
    },
    phone : {
        type : String,
        require : true
    }

})

const book = mongoose.model("book",bookSchema);

module.exports = book;