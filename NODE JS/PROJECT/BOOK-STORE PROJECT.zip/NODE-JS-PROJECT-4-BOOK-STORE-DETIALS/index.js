const express = require('express');

const port = 9999;

const app = express();

const path = require('path');

app.use(express.urlencoded());

app.use("/",express.static(path.join(__dirname,"public")))

const Database = require('./config/database');
const book = require("./model/schema");

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    book.find({}).then((alldata)=>{
        res.render('index',{
            data : alldata
        })
    })
})

app.post("/insert",(req,res)=>{
    book.create({
        bookname : req.body.bookname,
        author : req.body.author,
        company : req.body.company,
        email : req.body.email,
        phone: req.body.phone
    }).then(()=>{
        console.log("Book Added");
        return res.redirect("insert");
    })
})
app.get("/insert",(req,res)=>{
    book.find({}).then((alldata)=>{
        res.render("result",{
            data : alldata
        })
    })
})

app.get("/delete",(req,res)=>{
    let id = req.query.id;

    book.findByIdAndDelete(id).then(()=>{
        console.log("Book Deleted");
        return res.redirect('insert');
    })
})

app.get("/edit",(req,res)=>{
    let id = req.query.id;

    book.findById(id).then((alldata)=>{
        res.render("edit",{
            edit : alldata
        })
    })
})

app.post("/update",(req,res)=>{
    let id = req.body.id;

    book.findByIdAndUpdate(id,{
        bookname : req.body.bookname,
        author : req.body.author,
        company : req.body.company,
        email : req.body.email,
        phone : req.body.phone,
    }).then(()=>{
        console.log("Data Updated");
        return res.redirect("insert");
    })
})
app.listen(port,()=>{
    console.log("Server Started At - "+ port);
})