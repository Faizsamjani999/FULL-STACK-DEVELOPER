const express = require("express");
const port = 1111;
const app = express();
const path = require('path');
const cookie = require('cookie-parser');
const database = require("./config/database");
const data = require("./model/schema");

app.use(cookie());
app.use(express.urlencoded());
app.set("view engine","ejs");
app.use(express.static(path.join(__dirname,"public")));
app.use(express.static(path.join(__dirname,"pub")));
app.use(express.static(path.join(__dirname,"blogpublic")));
app.use("/upload",express.static(path.join(__dirname,"upload")));

app.use(require("./routes/route"));

app.listen(port,()=>{
    console.log("Server Started At -",port);
})