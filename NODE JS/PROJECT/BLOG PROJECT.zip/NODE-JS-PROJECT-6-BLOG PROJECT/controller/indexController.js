const express = require('express');
const data = require("../model/schema");
const fs = require('fs');

const index = (req,res)=>{
    res.render("signup");
}
const insert = (req,res)=>{
    let info = req.body;

    console.log(info);

    res.cookie("username",info.username);
    res.cookie("pass",info.pass);

    res.render("signin");
}
const signin = (req,res)=>{
    console.log("Signin Detail Start");
    console.log(req.cookies.username);
    console.log(req.cookies.pass);

    let allinfo = req.body;

    console.log(allinfo);
    console.log(allinfo.usr2);
    console.log(allinfo.pass2);

    if(req.cookies.username == allinfo.usr2 && req.cookies.pass == allinfo.pass2)
    {
        res.render("index");
    }
    else{
        res.render("signin");
    }
}
const dataForm = (req,res)=>{
    res.render('dataForm');
}
const insertAdminData = (req,res)=>{
    data.create({
        project : req.body.project,
        date : req.body.date,
        section : req.body.section,
        comments : req.body.comments,
        dec : req.body.dec,
        image : req.file.path
    }).then(()=>{
        console.log("Inserted...");
        res.render("dataForm");
    })
}
const viewData = (req,res)=>{
    data.find({}).then((result)=>{
        res.render('blog',{
            showresult : result
        })
    })
}
const deleted = (req,res)=>{
    let id = req.query.id;

    data.findById(id).then((result)=>{
        fs.unlinkSync(result.image);
    })

    data.findByIdAndDelete(id).then(()=>{
        console.log("Deleted");
        res.redirect("/viewdata");
    })
}
const edit = (req,res)=>{
    let id = req.query.id;

    data.findById(id).then((result)=>{
        res.render("edit",{
            showresult : result
        })
    })
}
const update = (req,res)=>{
    let id = req.body.id;

    if(req.file)
    {
        var obj = {
            project : req.body.project,
            date : req.body.date,
            section : req.body.section,
            comments : req.body.comments,
            dec : req.body.dec,
            image : req.file.path
        }
    }
    else
    {
        var obj = {
            project : req.body.project,
            date : req.body.date,
            section : req.body.section,
            comments : req.body.comments,
            dec : req.body.dec
        }
    }

    data.findById(id).then((result)=>{
        fs.unlinkSync(result.image);
    })

    data.findByIdAndUpdate(id,obj).then(()=>{
        console.log("Updated");
        res.redirect("/viewdata")
    })
}

module.exports = {
    index,
    insert,
    signin,
    dataForm,
    insertAdminData,
    viewData,
    deleted,
    edit,
    update
}