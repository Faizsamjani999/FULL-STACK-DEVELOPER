const express = require('express');

const port = 8888;

const app = express();

const path = require('path');

const checkpoint = (req,res,next)=>{
    if(req.query.age >= 18)
    {
        return next()
    }
    else
    {
        res.end();
    }
}

app.use("/",express.static(path.join(__dirname,"public")));

app.set("view engine","ejs");

app.get("/",checkpoint,(req,res)=>{
    res.render("index");
})

app.listen(port,()=>{
    console.log("Server Started At:- " + port);
})