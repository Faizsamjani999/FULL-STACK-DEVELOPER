const express = require('express');

const port = 8888;

const app = express();

app.use(express.urlencoded());

let menu = [
    {
        no : 1,
        customer : "M.Faiz Samjani",
        name : "Pizza",
        price : 250,
        location : "Imperial Palace Rajkot -",
        number : +91-4654546546
    },
    {
        no : 2,
        customer : "M.Faiz Samjani",
        name : "Sandwich",
        price : 140,
        location : "Imperial Palace Rajkot -",
        number : +91-4654546546
    },
    {
        no : 3,
        customer : "M.Faiz Samjani",
        name : "Burger",
        price : 120,
        location : "Imperial Palace Rajkot -",
        number : +91-4654546546
    }
    
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        menuDetail : menu
    });
})

app.post("/insert",(req,res)=>{
    console.log(req.body);

    let no = req.body.no;
    let customer = req.body.customer;
    let name = req.body.name;
    let price = req.body.price;
    let location = req.body.location;
    let number = req.body.number;

    let obj = {
        no : no,
        customer : customer,
        name : name,
        price : price,
        location : location,
        number : number
    }

    menu.push(obj);
    res.redirect("back");
})



app.get("/delete",(req,res)=>{
    let no = req.query.no;

    let ans = menu.filter((val)=>{
        return val.no != no;
    })
    menu = ans;
    res.redirect("back");
})

app.get("/edit",(req,res)=>{
    let no = req.query.no;

    let editData = menu.filter((val)=>{
        return val.no == no;
    })
    res.render("edit",{
        editAns : editData[0]
    })
})

app.post("/update",(req,res)=>{
    let no = req.body.no;

    let ans = menu.filter((val)=>{
        if(val.no == no){
            val.customer = req.body.customer;
            val.name = req.body.name;
        }
        return val;
    })
    menu = ans;

    res.redirect("/");
})

app.listen(port,()=>{
    console.log("Server Started At = ",port);
})