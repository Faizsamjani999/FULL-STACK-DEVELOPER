const express = require('express');
const table = require('../model/schema');
const bcrypt = require('bcrypt');

const index = (req,res)=>{
    res.render("signup");
}
const insert = async(req,res)=>{
    // const data = await table.create(req.body);

    // console.log(data);

    const data = {
        fname : req.body.fname,
        username : req.body.username,
        password : req.body.password
    }
    console.log(data);

    const existinguser = await table.findOne({username:data.username});

    if(existinguser)
    {
        res.send("User Already Exist...");
    }
    else{
        const passLength = 10;
        const hashpassword = await bcrypt.hash(data.password,passLength);
        data.password = hashpassword;
        table.create(data);
        res.render('signin');
    }
}

const signin = (req,res)=>{
    res.render("signin");
}

const home = async(req,res)=>{
    try{
        const check = await table.findOne({username:req.body.username});

        if(!check)
        {
            res.send("User Not Exists...");
        }
        const ps = await bcrypt.compare(req.body.password,check.password);

        if(ps)
        {
            res.render("home");
        }
        else{
            res.send("Wrong Password...");
        }
    }
    catch{
        res.send("Not Found...")
    }
}


module.exports = {
    index,
    insert,
    signin,
    home
    
}