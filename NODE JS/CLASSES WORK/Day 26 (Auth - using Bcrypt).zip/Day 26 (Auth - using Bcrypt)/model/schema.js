const mongoose = require('mongoose');

const schema = mongoose.Schema({
    fname : {
        type : String,
        required : true
    },
    username : {
        type : String,
        required : true
    },
    password : {
        type : String,
        required : true
    }
})

const table = mongoose.model("Table-1",schema);

module.exports = table;