const mongoose = require('mongoose');

mongoose.connect("mongodb://127.0.0.1/Auth-With-Bcrypt");

const db = mongoose.connection;

db.on("connected",()=>{
    console.log( "MongoDB connected successfully!" );
})

module.exports = db;