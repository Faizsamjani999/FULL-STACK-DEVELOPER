const express = require('express');
const port = 1111;
const app = express();

const database = require('./config/database');
const table = require('./model/schema');

app.use(express.urlencoded());
app.set("view engine","ejs");

app.use(require('./routes/route'));

app.listen(port,()=>{
    console.log("Server Started At -",port);
})

