const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');

route.get("/",indexController.index);

route.post("/insert",indexController.insert);

route.get("/insert",indexController.signin);

route.post("/login",indexController.home);

module.exports = route;