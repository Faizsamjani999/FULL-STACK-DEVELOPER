const mongoose = require('mongoose');

const studentSchema = mongoose.Schema({
    fname : {
        type : String,
        require : true,
    },
    lname : {
        type : String,
        require : true
    },
    email : {
        type : String,
        require : true
    }
})

const student = mongoose.model("student",studentSchema);

module.exports = student;