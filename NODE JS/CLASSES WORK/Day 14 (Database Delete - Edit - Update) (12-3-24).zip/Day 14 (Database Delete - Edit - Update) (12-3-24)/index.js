const express = require('express');

const port = 9999;

const app = express();

app.use(express.urlencoded());

const database = require('./config/database');

const student = require('./model/schema');

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    
    student.find({}).then((alldata)=>{
        res.render("form",{
            data : alldata
        })
    })
})

app.post("/insert",(req,res)=>{
    student.create({
        fname : req.body.fname,
        lname : req.body.lname,
        email : req.body.email
    }).then(()=>{
        console.log("Data Insert...");
        return res.redirect("/");
    }).catch((err)=>{
        console.log(err);
    })
})

app.get("/delete",(req,res)=>{
    let id = req.query.id

    // console.log(id);

    student.findByIdAndDelete(id).then(()=>{
        console.log("Data Deleted...");
        return res.redirect('/');
    })
    
})

app.get("/edit",(req,res)=>{
    let id = req.query.id;
    console.log(id);

    student.findById(id).then((alldata)=>{
        res.render("edit",{
            edit : alldata
        })
    })
})

app.post("/update",(req,res)=>{
    let id = req.body.id;

    student.findByIdAndUpdate(id,{
        fname : req.body.fname,
        lname : req.body.lname,
        email : req.body.email
    }).then(()=>{
        console.log("data updated");
        res.redirect('/');
    })
})

app.listen(port,()=>{
    console.log("Server Started At = " + port);
})