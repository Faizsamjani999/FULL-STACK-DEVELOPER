const express = require('express');

const port = 9999;

const app = express();

app.use(express.urlencoded());
const studentData = [
    {
        id : 1,
        name : "Mohammadfaiz",
        email : "fs999@gmail.com",
        password : 1234
    }
]

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index",{
        student : studentData
    });
})

app.listen(port,(err)=>{
    if(err)
    {
        console.log("Server Not Started = ");
        return false;
    }
    else
    {
        console.log("Server is Started = " + port);
    }
})