const http = require('http');

const port = 9999;

const server = http.createServer();

server.listen(port,(err)=>{
    if(err)
    {
        console.log("Server not started...");
    }
    else
    {
        console.log("Server Started Successfully...");
    }
})