const addition ={
    sum : function(){
        const a = 10;
        const b = 20;

        const c = console.log(a+b);
        // console.log(c);
    }
}
module.exports = addition;  // export our module to main file

// const substraction = {
//     sub : function(){
//         const x = 250;
//         const y = 150;

//         const z = console.log(x - y);
//         console.log("Substraction of = " + z);
//     }
// }
// module.exports = substraction;