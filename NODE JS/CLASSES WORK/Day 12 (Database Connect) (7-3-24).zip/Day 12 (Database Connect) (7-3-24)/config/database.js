const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1/RNW');

const db = mongoose.connection;

db.on('connected',(err)=>{
    if(err)
    {
        console.log("Database Not Connected...");
        return false;
    }
    else
    {
        console.log("Database Connected Successfully...");
    }
})

module.exports = db;