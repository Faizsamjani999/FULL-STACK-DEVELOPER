const mongoose = require('mongoose');

const studentSchema = mongoose.Schema({
    name : {
        type : String,
        require : true
    },
    surname : {
        type : String,
        require : true
    },
    email : {
        type : String,
        require : true
    },
    mobile : {
        type : String,
        require : true
    },
    password : {
        type : String,
        require : true
    }
})

const student = mongoose.model("student",studentSchema);

module.exports = student;