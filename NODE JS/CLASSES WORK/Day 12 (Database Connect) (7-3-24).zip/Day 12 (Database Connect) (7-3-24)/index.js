const express = require('express');

const port = 8888;

const app = express();

const database = require('./config/database');

const student = require('./model/student');

app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("index");
})

app.listen(port,()=>{
    console.log("Server Started At = "+ port);
})