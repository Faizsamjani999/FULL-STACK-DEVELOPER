const express = require('express');

const port = 9999;


const app = express();
app.set("view engine","ejs");

app.get("/",(req,res)=>{
    res.render("home");
})

app.get("/about",(req,res)=>{
    res.render("about");
})

app.listen(port,(err)=>{
    if(err)
    {
        console.log("Not Started");
    }
    else
    {
        console.log("Started Successfully...");
    }
})