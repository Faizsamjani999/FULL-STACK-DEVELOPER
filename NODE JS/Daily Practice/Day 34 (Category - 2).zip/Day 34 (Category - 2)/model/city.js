const mongoose = require('mongoose');

const schema = mongoose.Schema({
    stateId : {
        type : mongoose.Schema.Types.ObjectId,
        ref : "state"
    },
    city : {
        type : String,
        require : true
    }
})

const city = mongoose.model("city",schema);

module.exports = city;