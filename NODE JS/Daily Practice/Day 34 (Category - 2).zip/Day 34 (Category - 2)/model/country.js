const mongoose = require('mongoose');

const schema = mongoose.Schema({
    country : {
        type : String,
        require : true
    }
})

const country = mongoose.model("country",schema);

module.exports = country;