const mongoose = require('mongoose');

const schema = mongoose.Schema({
    countryId : {
        type : mongoose.Schema.Types.ObjectId,
        ref : "country"
    },
    state : {
        type : String,
        require : true
    }
})

const state = mongoose.model("state",schema);

module.exports = state;