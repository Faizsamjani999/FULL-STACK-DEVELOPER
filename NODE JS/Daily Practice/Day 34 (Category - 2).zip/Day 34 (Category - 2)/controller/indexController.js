const country = require("../model/country");
const states = require('../model/state');

const main = (req,res)=>{
    res.render("main");
}
const mainPost = (req,res)=>{
    country.create(req.body);

    res.redirect("/state");
}
const state = (req,res)=>{
    country.find({}).then((alldata)=>{
        res.render("state",{
            data : alldata
        })
    })
}

const statePost = async(req,res)=>{
    await states.create(req.body);

    res.redirect("/city");
}

const viewandcity = (req,res)=>{
    states.find({}).populate("countryId").then((alldata)=>{
        res.render("city",{
            data : alldata
        })
    })
}



module.exports = {
    main,
    mainPost,
    state,
    statePost,
    viewandcity
}