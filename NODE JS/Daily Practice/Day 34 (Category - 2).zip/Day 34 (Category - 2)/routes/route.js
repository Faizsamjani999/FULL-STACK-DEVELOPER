const express = require('express');

const route = express.Router();

const indexController = require('../controller/indexController');

route.get("/",indexController.main);

route.post("/state",indexController.mainPost);

route.get("/state",indexController.state);

route.post("/city",indexController.statePost);

route.get("/city",indexController.viewandcity);



module.exports = route