const express = require('express');
const port = 9999;
const app = express();
const database = require('./config/database');
const country = require('./model/country');
const state = require('./model/state');

app.use(express.urlencoded());

app.set("view engine","ejs");

app.use(require('./routes/route'));

app.listen(port,()=>{
    console.log("Server Started At -",port);
})