# stonehenge.js

> Tiny jQuery plugin to display mouse/finger draggable carousel
